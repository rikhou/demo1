import 'package:flutter/material.dart';
import 'pos.dart';
import 'shopping_cart.dart';

class PosPage extends StatefulWidget {
  const PosPage({super.key});

  @override
  State<PosPage> createState() => _PosPageState();
}

class _PosPageState extends State<PosPage> {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          flex: 3,
          child: Pos(),
        ),
        const Expanded(
          flex: 2,
          child: ShoppingCart(),
        )
      ],
    );
  }
}
