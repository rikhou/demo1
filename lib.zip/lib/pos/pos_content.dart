import 'package:flutter/material.dart';
import './pos_tab.dart';
import './pos_cards.dart';

class PosContent extends StatelessWidget {
  const PosContent({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
        // color: Colors.green,
        child: Column(children: [PosTab(), PosCards()]));
  }
}
