import 'package:flutter/material.dart';
import 'pos_title.dart';
import 'pos_content.dart';

class Pos extends StatelessWidget {
  Pos({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color.fromARGB(255, 242, 243, 246),
      child: Column(
        children: [
          PosTitle(),
          PosContent(),
        ],
      ),
    );
  }
}
