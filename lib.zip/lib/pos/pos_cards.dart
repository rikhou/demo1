import 'package:flutter/material.dart';
import "./pos_card.dart";

class Product {
  const Product({required this.name});
  final String name;
}

class PosCards extends StatefulWidget {
  const PosCards({super.key});

  @override
  State<PosCards> createState() => _PosCardsState();
}

class _PosCardsState extends State<PosCards> {
  final List<Product> products = [
    Product(name: 'Eggs'),
    Product(name: 'ee'),
    Product(name: 'Flour'),
    Product(name: 'ss'),
    Product(name: 'Chocolate chips'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ListView(
        shrinkWrap: true,
        itemExtent: 30,
        scrollDirection: Axis.vertical,
        padding: const EdgeInsets.all(30),
        children: products.map((product) {
          return const PosCard();
        }).toList(),
      ),
    );
  }
}
