import 'package:flutter/material.dart';

class PosTab extends StatelessWidget {
  const PosTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color.fromARGB(255, 242, 243, 246),
      padding: const EdgeInsets.fromLTRB(30, 30, 30, 30),
      child: Container(
        alignment: Alignment.topLeft,
        color: Colors.white,
        padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
        child: TextButton(
          style: ButtonStyle(
            foregroundColor: MaterialStateProperty.all(Colors.black45),
            textStyle: MaterialStateProperty.all(const TextStyle(fontSize: 18)),
            minimumSize: MaterialStateProperty.all(const Size(80, 80)),
            padding: MaterialStateProperty.all(EdgeInsets.zero),
            shape: MaterialStateProperty.all(
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
          ),
          onPressed: () => {},
          child: Text("Pinned(0)"),
        ),
      ),
    );
  }
}
