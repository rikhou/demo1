import 'package:flutter/material.dart';

class PosCard extends StatelessWidget {
  const PosCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.green,
      // padding: const EdgeInsets.fromLTRB(30, 30, 30, 30),
      child: Container(
        child: Text("pos"),
      ),
    );
  }
}
